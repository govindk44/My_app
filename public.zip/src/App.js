import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import Navbar from './Component/Navbar';
import Skills from './components/skills';
import Project from './components/project';



export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/home" element={<Home />} /> 
          <Route path='/Skils' element={<Skills/>}/>
          <Route path='/project' element={<Project/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
