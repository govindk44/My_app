import React from 'react';
import './skills.css';
const Skills = () => {
  const skillSet = ["Python", "Java", "C", "C++", "Django", "SQL", "HTML", "CSS"];

  return (
    <div>
      <h2>Skills</h2>
      <ul>
        {skillSet.map((skill, index) => (
          <li key={index}>{skill}</li>
        ))}
      </ul>
    </div>
  );
};

export default Skills;
