import React from 'react'
// import Navbar from '../Component/Navbar'

const Home = () => {
  return (
    <div>
      {/* <Navbar/> */}
      <p>
        hello 




      </p>
    </div>
  )
}

export default Home
