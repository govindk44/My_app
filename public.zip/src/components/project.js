import React from 'react';

const Project = () => {
  const projectList = [
    { name: "Medical Store Management System", description: "A system for managing medicines and stock.", techStack: "React, Django" },
    { name: "Vehicle Renting System", description: "A platform for renting vehicles.", techStack: "React, Node.js" },
    { name: "Cricket Score Dashboard", description: "A dashboard to display live cricket scores.", techStack: "React, Node.js, MySQL" },
  ];

  return (
    <div>
      <h2>Projects</h2>
      <ul>
        {projectList.map((project, index) => (
          <li key={index}>
            <h3>{project.name}</h3>
            <p>{project.description}</p>
            <p><strong>Tech Stack:</strong> {project.techStack}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Project;
